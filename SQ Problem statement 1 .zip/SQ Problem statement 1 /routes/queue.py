from flask import Blueprint, request, jsonify
from database.database import db
from database.models import Student, ServicePoint, Counter, QueueEntry
from services.queue_engine import QueueEngine
from services.waiting_time import WaitingTimeService

queue_bp = Blueprint("queue", __name__)

@queue_bp.route("/queue/join", methods=["POST"])
def join_queue():
    data = request.get_json(silent=True) or {}
    student_id, service_point_id = data.get("student_id"), data.get("service_point_id")
    if not student_id or not service_point_id:
        return jsonify({"error": "student_id and service_point_id are required"}), 400
    if not Student.query.get(student_id):
        return jsonify({"error": "Student not found"}), 404
    if not ServicePoint.query.get(service_point_id):
        return jsonify({"error": "Service point not found"}), 404
    entry = QueueEngine.join_queue(student_id, service_point_id)
    position = QueueEngine.get_position(entry.id)
    people_ahead = max(0, position - 1) if position else 0
    eta = WaitingTimeService.calculate_eta(service_point_id, people_ahead)
    entry.estimated_wait = eta
    db.session.commit()
    return jsonify({"message": "Successfully joined queue", "token": entry.token,
                    "position": position, "people_ahead": people_ahead,
                    "estimated_wait_minutes": eta, "status": entry.status}), 201

@queue_bp.route("/queue/<int:service_point_id>", methods=["GET"])
def get_queue(service_point_id):
    queue = QueueEngine.get_queue(service_point_id)
    result = []
    for position, entry in enumerate(queue, start=1):
        ahead = position - 1
        result.append({"id": entry.id, "token": entry.token, "position": position,
                       "people_ahead": ahead,
                       "estimated_wait_minutes": WaitingTimeService.calculate_eta(service_point_id, ahead),
                       "status": entry.status})
    return jsonify({"service_point_id": service_point_id, "queue_length": len(result), "queue": result})

@queue_bp.route("/queue/cancel/<int:queue_entry_id>", methods=["POST"])
def cancel_queue(queue_entry_id):
    entry = QueueEntry.query.get(queue_entry_id)
    if not entry or entry.status != "WAITING":
        return jsonify({"error": "Queue entry is not waiting"}), 409
    from datetime import datetime
    entry.status = "CANCELLED"
    entry.cancelled_at = datetime.utcnow()
    db.session.commit()
    return jsonify({"message": "Queue entry cancelled", "token": entry.token})

@queue_bp.route("/counter/<int:counter_id>/toggle", methods=["POST"])
def toggle_counter(counter_id):
    counter = Counter.query.get(counter_id)
    if not counter:
        return jsonify({"error": "Counter not found"}), 404
    if counter.status == "BUSY":
        return jsonify({"error": "Finish the current student before closing this counter"}), 409
    counter.status = "CLOSED" if counter.status == "OPEN" else "OPEN"
    db.session.commit()
    return jsonify({"id": counter.id, "status": counter.status})

@queue_bp.route("/queue/serving/<int:service_point_id>", methods=["GET"])
def serving(service_point_id):
    rows = QueueEntry.query.filter_by(service_point_id=service_point_id, status="SERVING").all()
    counters = Counter.query.filter_by(service_point_id=service_point_id).all()
    return jsonify({"serving": [{
        "id": r.id,
        "token": r.token,
        "counter_number": next((c.counter_number for c in counters if c.current_token == r.token), None),
    } for r in rows]})

@queue_bp.route("/queue/serve-next", methods=["POST"])
def serve_next():
    data = request.get_json(silent=True) or {}
    service_point_id, counter_id = data.get("service_point_id"), data.get("counter_id")
    if not service_point_id or not counter_id:
        return jsonify({"error": "service_point_id and counter_id are required"}), 400
    entry, reason = QueueEngine.serve_next(service_point_id, counter_id)
    if reason == "COUNTER_BUSY":
        return jsonify({"error": "Counter is already serving a student"}), 409
    if reason == "QUEUE_EMPTY":
        return jsonify({"error": "Queue is empty"}), 404
    if reason != "OK":
        return jsonify({"error": reason}), 400
    return jsonify({"message": "Next student is now being served", "token": entry.token,
                    "queue_entry_id": entry.id, "counter_id": counter_id, "status": entry.status})

@queue_bp.route("/queue/complete/<int:queue_entry_id>", methods=["POST"])
def complete_queue(queue_entry_id):
    entry = QueueEngine.complete_service(queue_entry_id)
    if not entry:
        return jsonify({"error": "Queue entry is not currently being served"}), 409
    return jsonify({"message": "Service completed", "token": entry.token,
                    "status": entry.status, "actual_wait_minutes": round(entry.actual_wait or 0, 2)})

@queue_bp.route("/demo/history", methods=["POST"])
def load_demo_history():
    """Create deterministic-ish historical records for a presentation dashboard.
    Existing history is preserved; repeated calls add another small sample window.
    """
    data = request.get_json(silent=True) or {}
    service_point_id = data.get("service_point_id", 1)
    days = min(max(int(data.get("days", 3)), 1), 7)
    samples = min(max(int(data.get("samples_per_day", 18)), 6), 40)
    point = ServicePoint.query.get(service_point_id)
    if not point:
        return jsonify({"error": "Service point not found"}), 404
    from simulation.demo_data import create_demo_history
    create_demo_history(service_point_id=service_point_id, days=days, samples_per_day=samples)
    return jsonify({"message": f"Added {days * samples} historical service samples", "days": days, "samples": days * samples}), 201

@queue_bp.route("/demo/load", methods=["POST"])
def load_demo_queue():
    """Add a small realistic live queue for a presentation/demo."""
    data = request.get_json(silent=True) or {}
    service_point_id = data.get("service_point_id", 1)
    count = min(max(int(data.get("count", 6)), 1), 12)
    point = ServicePoint.query.get(service_point_id)
    if not point:
        return jsonify({"error": "Service point not found"}), 404
    import time
    created = []
    for i in range(count):
        anonymous = f"DEMO-{time.time_ns()}-{i}"
        student = Student(anonymous_identifier=anonymous)
        db.session.add(student)
        db.session.flush()
        entry = QueueEngine.join_queue(student.id, service_point_id)
        created.append(entry.token)
    return jsonify({"message": f"Added {count} demo students", "tokens": created}), 201
