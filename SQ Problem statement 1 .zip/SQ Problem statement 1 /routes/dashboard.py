from flask import Blueprint, jsonify
from datetime import datetime, timedelta
from database.models import ServicePoint, Counter, QueueEntry, ServiceRecord
from algorithms.queue_analytics import snapshot, hourly_trend
from ml.wait_predictor import WaitPredictor
from services.recommendation import recommendation, peak_window
from services.queue_engine import QueueEngine

analytics_bp = Blueprint("dashboard", __name__)

@analytics_bp.route("/dashboard/<int:service_point_id>", methods=["GET"])
def dashboard(service_point_id):
    point = ServicePoint.query.get(service_point_id)
    if not point:
        return jsonify({"error": "Service point not found"}), 404
    snap = snapshot(service_point_id)
    counters = Counter.query.filter_by(service_point_id=service_point_id).order_by(Counter.counter_number).all()
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    tomorrow_start = today_start + timedelta(days=1)
    today_completed = QueueEntry.query.filter(
        QueueEntry.service_point_id == service_point_id,
        QueueEntry.status == "COMPLETED",
        QueueEntry.completed_at >= today_start,
        QueueEntry.completed_at < tomorrow_start,
    ).count()
    serving = QueueEntry.query.filter_by(service_point_id=service_point_id, status="SERVING").all()
    pred = WaitPredictor.predict(service_point_id)
    peak, peak_status = peak_window()
    return jsonify({
        "service_point": {"id": point.id, "name": point.name, "status": point.status},
        "metrics": {**snap, "completed_total": today_completed},
        "counters": [{"id": c.id, "number": c.counter_number, "status": c.status, "current_token": c.current_token} for c in counters],
        "serving": [{
            "id": e.id,
            "token": e.token,
            "counter_number": next((c.counter_number for c in counters if c.current_token == e.token), None),
        } for e in serving],
        "prediction": pred,
        "recommendation": recommendation(service_point_id),
        "peak": {"window": peak, "status": peak_status},
        "trend": hourly_trend(service_point_id),
    })

@analytics_bp.route("/analytics/<int:service_point_id>", methods=["GET"])
def analytics(service_point_id):
    records = ServiceRecord.query.join(QueueEntry, ServiceRecord.queue_entry_id == QueueEntry.id)\
        .filter(QueueEntry.service_point_id == service_point_id, ServiceRecord.service_duration.isnot(None)).all()
    durations = [round(r.service_duration, 2) for r in records]
    return jsonify({"sample_count": len(durations), "service_durations": durations,
                    "trend": hourly_trend(service_point_id)})
