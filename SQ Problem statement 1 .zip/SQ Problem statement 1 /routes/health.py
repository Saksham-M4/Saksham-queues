from flask import Blueprint
health_bp = Blueprint("health", __name__)

@health_bp.route("/health", methods=["GET"])
def health():
    return {"status": "OK", "application": "SmartQueue", "message": "Backend is running"}
