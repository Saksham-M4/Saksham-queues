from flask import Blueprint,request,jsonify
from datetime import datetime,timedelta
from sqlalchemy import func
from database.database import db
from database.models import Student,ServicePoint,MenuItem,Order,OrderItem,QueueEntry,Notification,Counter,ServiceRecord,QueueEvent
from services.queue_engine import QueueEngine
from services.waiting_time import WaitingTimeService
food_bp=Blueprint('food',__name__)

def stall_json(s): return {'id':s.id,'name':s.name,'location':s.location,'status':s.status,'created_by_email':s.created_by_email,'is_active':s.is_active}

def counter_json(c): return {'id':c.id,'number':c.counter_number,'status':c.status,'current_token':c.current_token}

def order_payload(o):
    e=QueueEntry.query.get(o.queue_entry_id)
    active=[x for x in QueueEntry.query.filter_by(service_point_id=o.service_point_id,status='WAITING').order_by(QueueEntry.joined_at).all()]
    pos=next((i+1 for i,x in enumerate(active) if x.id==o.queue_entry_id),None)
    ahead=max(0,(pos or 1)-1)
    c=Counter.query.get(o.counter_id) if o.counter_id else None
    return {'id':o.id,'order_number':o.order_number,'token':e.token if e else None,'status':o.status,'total':o.total,
            'eta_minutes':o.eta_minutes,'eta_at':o.eta_at.isoformat() if o.eta_at else None,'message':o.admin_message,
            'stall_id':o.service_point_id,'position':pos,'people_ahead':ahead,'counter':counter_json(c) if c else None,
            'created_at':o.created_at.isoformat(),'updated_at':o.updated_at.isoformat(),
            'items':[{'name':x.name,'price':x.price,'quantity':x.quantity} for x in OrderItem.query.filter_by(order_id=o.id).all()]}

@food_bp.route('/auth/login',methods=['POST'])
def login():
    d=request.get_json(silent=True) or {}; role=d.get('role','student')
    if d.get('email')=='unser01@gmail.com' and d.get('password')=='12345678' and role in ('student','admin'):
        return jsonify({'ok':True,'role':role,'email':d['email'],'demo':True})
    return jsonify({'error':'Invalid demo credentials'}),401

@food_bp.route('/stalls')
def stalls():
    return jsonify({'stalls':[stall_json(s) for s in ServicePoint.query.filter_by(is_active=True).order_by(ServicePoint.id).all()]})

@food_bp.route('/stalls/<int:stall_id>/menu')
def menu(stall_id):
    s=ServicePoint.query.get_or_404(stall_id)
    return jsonify({'stall':stall_json(s),'items':[{'id':i.id,'name':i.name,'price':i.price,'available':i.available,'category':i.category} for i in MenuItem.query.filter_by(service_point_id=stall_id).order_by(MenuItem.id).all()]})

@food_bp.route('/admin/stalls',methods=['POST'])
def add_stall():
    d=request.get_json(silent=True) or {}; s=ServicePoint(name=d.get('name','New Stall'),location=d.get('location','GCU Campus'),type='stall',status='OPEN')
    db.session.add(s); db.session.commit(); return jsonify(stall_json(s)),201


@food_bp.route('/admin/stalls/<int:stall_id>',methods=['DELETE'])
def delete_stall(stall_id):
    d=request.get_json(silent=True) or {}
    email=str(d.get('email','')).strip().lower()
    s=ServicePoint.query.get_or_404(stall_id)
    if not s.is_active:
        return jsonify({'error':'Stall has already been removed'}),404
    if not s.created_by_email or email != s.created_by_email.lower():
        return jsonify({'error':'Only the admin who created this stall can remove it'}),403
    active_orders=Order.query.filter(
        Order.service_point_id==stall_id,
        Order.status.in_(['PLACED','PREPARING','READY','COLLECTED'])
    ).count()
    if active_orders:
        return jsonify({'error':f'Cannot remove this stall while {active_orders} active order(s) remain. Complete them first.'}),409
    s.is_active=False
    s.status='CLOSED'
    db.session.commit()
    return jsonify({'ok':True,'message':f'{s.name} removed from active stalls'})

@food_bp.route('/admin/stalls/<int:stall_id>/items',methods=['POST'])
def add_item(stall_id):
    stall=ServicePoint.query.get_or_404(stall_id)
    if not stall.is_active:return jsonify({'error':'Stall is no longer active'}),409
    d=request.get_json(silent=True) or {}
    item=MenuItem(service_point_id=stall_id,name=d.get('name','New Item'),price=float(d.get('price',0)),category=d.get('category','Food'),stock_target=int(d.get('stock_target',50)))
    db.session.add(item); db.session.commit(); return jsonify({'id':item.id,'name':item.name,'price':item.price,'available':item.available}),201

@food_bp.route('/admin/items/<int:item_id>',methods=['PATCH'])
def update_item(item_id):
    i=MenuItem.query.get_or_404(item_id); d=request.get_json(silent=True) or {}
    if 'name' in d:i.name=d['name']
    if 'price' in d:i.price=float(d['price'])
    if 'available' in d:i.available=bool(d['available'])
    if 'stock_target' in d:i.stock_target=int(d['stock_target'])
    if 'waste_count' in d:i.waste_count=max(0,int(d['waste_count']))
    db.session.commit(); return jsonify({'ok':True})

@food_bp.route('/orders',methods=['POST'])
def create_order():
    d=request.get_json(silent=True) or {}; student_id=int(d.get('student_id',1)); stall_id=int(d.get('service_point_id',1)); items=d.get('items',[])
    if not items:return jsonify({'error':'Cart is empty'}),400
    ServicePoint.query.get_or_404(stall_id)
    student=Student.query.get(student_id) or Student(anonymous_identifier=f'STUDENT-{student_id}')
    db.session.add(student); db.session.flush(); total=0
    validated=[]
    for x in items:
        mi=MenuItem.query.get(int(x['menu_item_id'])); qty=max(1,int(x.get('quantity',1)))
        if not mi or mi.service_point_id!=stall_id or not mi.available:return jsonify({'error':'One of the selected items is unavailable'}),409
        validated.append((mi,qty)); total+=mi.price*qty
    entry=QueueEngine.join_queue(student.id,stall_id)
    ahead=max(0,(QueueEngine.get_position(entry.id) or 1)-1)
    eta=WaitingTimeService.calculate_eta(stall_id,ahead); entry.estimated_wait=eta
    order=Order(order_number=f'ORD-{datetime.now().strftime("%Y%m%d")}-{entry.id:04d}',student_id=student.id,service_point_id=stall_id,queue_entry_id=entry.id,status='PLACED',total=total,eta_minutes=eta,eta_at=datetime.utcnow()+timedelta(minutes=eta),admin_message='Order received. Your place in the queue is confirmed.')
    db.session.add(order); db.session.flush()
    for mi,qty in validated:db.session.add(OrderItem(order_id=order.id,menu_item_id=mi.id,name=mi.name,price=mi.price,quantity=qty))
    db.session.add(Notification(student_id=student.id,type='ORDER',message=f'{order.order_number}: order placed. Token {entry.token}.'))
    db.session.commit(); return jsonify(order_payload(order)),201

@food_bp.route('/orders')
def orders():
    return jsonify({'orders':[order_payload(o) for o in Order.query.order_by(Order.created_at.desc()).all()]})

@food_bp.route('/orders/<int:order_id>/status',methods=['POST'])
def update_order(order_id):
    o=Order.query.get_or_404(order_id); d=request.get_json(silent=True) or {}; status=d.get('status',o.status)
    allowed={'PLACED','PREPARING','READY','COLLECTED','COMPLETED','CANCELLED'}
    if status not in allowed:return jsonify({'error':'Invalid status'}),400
    now=datetime.utcnow(); o.status=status; o.updated_at=now
    if d.get('message') is not None:o.admin_message=str(d['message'])[:500]
    if d.get('eta_minutes') is not None:
        o.eta_minutes=max(0,float(d['eta_minutes'])); o.eta_at=now+timedelta(minutes=o.eta_minutes)
    if d.get('counter_id'):
        c=Counter.query.get(int(d['counter_id']))
        if not c or c.service_point_id!=o.service_point_id:return jsonify({'error':'Invalid counter'}),400
        o.counter_id=c.id
    e=QueueEntry.query.get(o.queue_entry_id)
    if status=='PREPARING' and e and e.status=='WAITING':
        e.status='SERVING';e.called_at=now
        if not o.counter_id:
            c=Counter.query.filter_by(service_point_id=o.service_point_id,status='OPEN').order_by(Counter.counter_number).first()
            if c:o.counter_id=c.id
        if o.counter_id:
            c=Counter.query.get(o.counter_id); c.current_token=e.token
            if not ServiceRecord.query.filter_by(queue_entry_id=e.id).first():
                db.session.add(ServiceRecord(queue_entry_id=e.id,counter_id=c.id,service_start=now))
    if status in ('READY','COLLECTED','COMPLETED') and e and e.status in ('WAITING','SERVING'):
        e.status='COMPLETED' if status=='COMPLETED' else 'SERVING'
        if status=='COMPLETED':
            e.completed_at=now
            rec=ServiceRecord.query.filter_by(queue_entry_id=e.id).order_by(ServiceRecord.id.desc()).first()
            if rec and rec.service_start and not rec.service_end:
                rec.service_end=now; rec.service_duration=max(0,(now-rec.service_start).total_seconds()/60); c=Counter.query.get(rec.counter_id)
                if c and c.current_token==e.token:c.current_token=None
    if status in ('READY','COLLECTED','COMPLETED'):
        db.session.add(Notification(student_id=o.student_id,type='ORDER_UPDATE',message=o.admin_message or f'{o.order_number} is {status.lower()}'))
    db.session.add(QueueEvent(service_point_id=o.service_point_id,token=e.token if e else None,event_type=status))
    db.session.commit(); return jsonify(order_payload(o))

@food_bp.route('/orders/<int:order_id>/cancel',methods=['POST'])
def cancel_order(order_id):
    o=Order.query.get_or_404(order_id)
    if o.status in ('COMPLETED','CANCELLED'):return jsonify({'error':'Order cannot be cancelled now'}),409
    o.status='CANCELLED';o.updated_at=datetime.utcnow();e=QueueEntry.query.get(o.queue_entry_id)
    if e:e.status='CANCELLED';e.cancelled_at=datetime.utcnow()
    db.session.add(Notification(student_id=o.student_id,type='ORDER_UPDATE',message=f'{o.order_number} was cancelled.'))
    db.session.commit();return jsonify(order_payload(o))

@food_bp.route('/student/<int:student_id>/orders')
def student_orders(student_id):return jsonify({'orders':[order_payload(o) for o in Order.query.filter_by(student_id=student_id).order_by(Order.created_at.desc()).limit(20).all()]})

@food_bp.route('/student/<int:student_id>/notifications')
def student_notifications(student_id):
    return jsonify({'notifications':[{'id':n.id,'type':n.type,'message':n.message,'read':n.read,'created_at':n.created_at.isoformat()} for n in Notification.query.filter_by(student_id=student_id).order_by(Notification.created_at.desc()).limit(20).all()]})

@food_bp.route('/admin/analytics/<int:stall_id>')
def analytics(stall_id):
    ServicePoint.query.get_or_404(stall_id)
    pending=Order.query.filter(Order.service_point_id==stall_id,Order.status.in_(['PLACED','PREPARING','READY','COLLECTED'])).count()
    completed=Order.query.filter(Order.service_point_id==stall_id,Order.status=='COMPLETED').count()
    revenue=db.session.query(func.coalesce(func.sum(Order.total),0)).filter(Order.service_point_id==stall_id,Order.status!='CANCELLED').scalar() or 0
    counters=Counter.query.filter_by(service_point_id=stall_id).all(); active=sum(c.status=='OPEN' for c in counters)
    items=MenuItem.query.filter_by(service_point_id=stall_id).all(); sold={i.id:0 for i in items}
    for oi in OrderItem.query.join(Order,Order.id==OrderItem.order_id).filter(Order.service_point_id==stall_id,Order.status.in_(['READY','COLLECTED','COMPLETED'])).all():sold[oi.menu_item_id]=sold.get(oi.menu_item_id,0)+oi.quantity
    demand=[{'name':i.name,'sold':sold.get(i.id,0),'waste':i.waste_count,'target':i.stock_target,'risk':'HIGH' if i.waste_count>max(2,i.stock_target*.12) else 'LOW'} for i in items]
    avg_eta=db.session.query(func.avg(Order.eta_minutes)).filter(Order.service_point_id==stall_id,Order.status.in_(['PLACED','PREPARING'])).scalar() or 0
    return jsonify({'pending':pending,'completed':completed,'revenue':round(float(revenue),2),'active_counters':active,'total_counters':len(counters),'avg_eta':round(float(avg_eta),1),'peak_window':'1:15 PM – 2:15 PM','demand':demand,'waste_message':'Reduce preparation for high-waste items; use live demand before the peak.'})

@food_bp.route('/admin/items/<int:item_id>/waste',methods=['POST'])
def record_waste(item_id):
    i=MenuItem.query.get_or_404(item_id);d=request.get_json(silent=True) or {};qty=max(1,int(d.get('quantity',1)));i.waste_count+=qty;db.session.commit();return jsonify({'ok':True,'waste_count':i.waste_count})
