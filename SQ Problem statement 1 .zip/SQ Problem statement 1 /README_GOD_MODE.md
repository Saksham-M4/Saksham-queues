# SmartQueue — God Mode Hackathon Build

This is the presentation-focused, local-first SmartQueue build.

## What is included

### Student experience
- Digital queue join and token
- Live position and people-ahead count
- Personal current ETA
- Leave/cancel queue
- Live queue visibility
- Queue health and peak-window insight

### Admin command center
- Live KPI strip
- Live waiting queue with FIFO ordering
- Now-serving cards
- Counter capacity map
- Open/close counter controls
- Complete-service workflow
- Busy-counter protection
- Automatic 5-second refresh

### Intelligence layer
- Current ETA separated from future forecast
- Queue congestion classification
- Transparent short-horizon 15/30/60 minute forecast
- Forecast reliability label tied to available service-history samples
- Smart staffing recommendation
- Peak-window context
- Throughput trend chart
- Weekly pressure heatmap (explicitly illustrative until enough history exists)
- Decision engine showing capacity utilization

### Demo tooling
- Load Demo: add a small live queue
- Load History: add historical service samples so analytics and reliability become meaningful

## Run

### Backend
```bash
source .venv/bin/activate
python3 app.py
```

### Frontend
In a second terminal:
```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

## Best 5-minute demo sequence

1. Start on Admin → Overview.
2. Click **Load History** once so the analytics have history.
3. Click **Load Demo** to create live demand.
4. Show the KPI strip and FIFO queue.
5. Show Now Serving and counter capacity.
6. Click **Serve Next Student** once.
7. Show the queue moving and forecast updating.
8. Complete the active service.
9. Show the counter returning to OPEN.
10. Switch to Student.
11. Join the queue and show the personal token, position and ETA.
12. Return to Admin and explain the decision engine.

## Technical honesty

The forecast is intentionally transparent and deterministic in this MVP. It uses live queue state, recent service history and time-of-day adjustment. It does not claim a statistical accuracy percentage unless real model evaluation data is available.

The weekly heatmap is labeled illustrative until sufficient historical data exists.
