from datetime import datetime
from services.waiting_time import WaitingTimeService
from services.queue_engine import QueueEngine
from algorithms.queue_analytics import congestion_level

try:
    from sklearn.ensemble import RandomForestRegressor  # optional local ML capability
    SKLEARN_AVAILABLE = True
except Exception:
    SKLEARN_AVAILABLE = False


class WaitPredictor:
    """Transparent local queue forecast.

    The MVP uses live queue state + recent service history + time-of-day demand
    adjustment. This is intentionally deterministic so the demo never invents
    unexplained values. sklearn is optional for future model training.
    """

    @staticmethod
    def _peak_factor(hour):
        if hour in (12, 13):
            return 1.20
        if hour in (10, 11, 14, 15):
            return 1.10
        return 1.00

    @staticmethod
    def predict(service_point_id):
        queue = QueueEngine.get_queue(service_point_id)
        active = QueueEngine.get_active_counters(service_point_id)
        busy = QueueEngine.get_busy_counters(service_point_id)
        avg = WaitingTimeService.get_average_service_time(service_point_id)
        current = len(queue)
        effective = max(1, active + busy)
        factor = WaitPredictor._peak_factor(datetime.now().hour)

        base_wait = (current * avg) / effective
        predicted_wait = round(base_wait * factor, 1)
        predicted_queue = max(0, round(current * factor))
        # This is a reliability label based on available historical service data,
        # not a statistical model accuracy/confidence score.
        history_records = WaitingTimeService.get_history_count(service_point_id)
        if history_records >= 10:
            reliability = "GOOD"
        elif history_records >= 3:
            reliability = "LIMITED"
        else:
            reliability = "LOW"

        forecasts = []
        for minutes in (15, 30, 60):
            # Conservative short-horizon forecast: current load plus a small
            # demand increment during peak hours.
            growth = 0.10 if factor >= 1.10 else 0.04
            projected_queue = max(0, round(current * (1 + growth * minutes / 30)))
            projected_wait = round((projected_queue * avg) / effective * factor, 1)
            forecasts.append({
                "minutes": minutes,
                "queue": projected_queue,
                "wait": projected_wait,
            })

        return {
            "predicted_queue": predicted_queue,
            "predicted_wait": predicted_wait,
            "congestion": congestion_level(predicted_queue, predicted_wait),
            "reliability": reliability,
            "history_samples": history_records,
            "model": "live queue + recent service history + time-of-day adjustment",
            "forecasts": forecasts,
            "peak_window": "12:00–2:00 PM",
            "ml_ready": SKLEARN_AVAILABLE,
        }
