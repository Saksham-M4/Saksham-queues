from datetime import datetime, timedelta
from database.models import QueueEntry, QueueEvent, ServiceRecord
from services.queue_engine import QueueEngine
from services.waiting_time import WaitingTimeService


def congestion_level(queue_length, avg_wait):
    score = queue_length * 2 + avg_wait
    if score >= 25:
        return "HIGH"
    if score >= 12:
        return "MODERATE"
    return "LOW"


def snapshot(service_point_id):
    queue = QueueEngine.get_queue(service_point_id)
    active = QueueEngine.get_active_counters(service_point_id)
    busy = QueueEngine.get_busy_counters(service_point_id)
    avg = WaitingTimeService.get_average_service_time(service_point_id)
    wait = WaitingTimeService.calculate_eta(service_point_id, max(0, len(queue) - 1))
    return {
        "queue_length": len(queue),
        "active_counters": active,
        "busy_counters": busy,
        "average_service_minutes": avg,
        "estimated_wait_minutes": wait,
        "congestion": congestion_level(len(queue), wait),
    }


def hourly_trend(service_point_id, hours=8):
    now = datetime.utcnow()
    result = []
    for offset in range(hours - 1, -1, -1):
        start = now - timedelta(hours=offset + 1)
        end = now - timedelta(hours=offset)
        joins = QueueEvent.query.filter_by(service_point_id=service_point_id, event_type="JOINED")\
            .filter(QueueEvent.timestamp >= start, QueueEvent.timestamp < end).count()
        completed = QueueEvent.query.filter_by(service_point_id=service_point_id, event_type="COMPLETED")\
            .filter(QueueEvent.timestamp >= start, QueueEvent.timestamp < end).count()
        label = end.strftime("%I %p").lstrip("0")
        result.append({"label": label, "joined": joins, "completed": completed})
    return result
