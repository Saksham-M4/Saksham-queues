# SmartQueue — Campus Queue Intelligence

Hackathon-ready local-first prototype for campus peak-hour queue management.

## What is included

- Student digital token + live position + ETA
- Admin operations center
- FIFO Serve Next logic
- Busy-counter protection (double-click cannot serve another student)
- Complete Service flow
- Counter OPEN / BUSY / CLOSED status
- Live queue polling every 5 seconds
- Queue analytics and recent activity chart
- AI-assisted congestion and wait prediction panel
- Smart operational recommendation
- Demo history generator
- Live demo queue generator
- Automated backend tests

## Architecture

React/Vite frontend → Flask REST API → SQLite → queue engine + analytics + prediction services.

## Run on Mac

### Terminal 1 — backend

```bash
cd /path/to/SmartQueue_A_to_Z
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 -m database.seed
python3 app.py
```

Backend: http://127.0.0.1:5001

### Terminal 2 — frontend

```bash
cd /path/to/SmartQueue_A_to_Z/frontend
npm install
npm run dev
```

Frontend: http://localhost:5173

## Demo data

Optional historical records:

```bash
cd /path/to/SmartQueue_A_to_Z
source .venv/bin/activate
python3 -m simulation.demo_data
```

Optional live queue:

```bash
python3 -m simulation.load_demo_queue
```

## Hackathon demo flow

1. Open Student view.
2. Click Join Queue.
3. Switch to Admin.
4. Click Serve Next ONCE.
5. Observe the token move to Now Serving.
6. Click Complete Service.
7. Repeat with another student.
8. Show counter status and live metrics.
9. Show AI Queue Intelligence.
10. Show Recent Activity analytics.

## API endpoints

- GET `/api/health`
- GET `/api/queue/<service_point_id>`
- POST `/api/queue/join`
- POST `/api/queue/serve-next`
- GET `/api/queue/serving/<service_point_id>`
- POST `/api/queue/complete/<queue_entry_id>`
- POST `/api/queue/cancel/<queue_entry_id>`
- POST `/api/counter/<counter_id>/toggle`
- GET `/api/dashboard/<service_point_id>`
- GET `/api/analytics/<service_point_id>`

## Important

This is a prototype. The prediction panel is deliberately transparent: it uses queueing/service-history information and a time-of-day adjustment, with an optional local ML dependency. It should be presented as an AI-assisted prototype, not as a validated production forecasting model.
