# SmartQueue Final Fixes

This revision fixes the remaining demo/presentation issues:

- Removed duplicated `Q` visual prefix in queue rows.
- Counter cards now clearly show `SERVING · Q-...` when busy.
- Now-serving data includes the actual counter number.
- Served Today counts only completions from the current UTC calendar day.
- AI panel now distinguishes a **forecast wait** from the live per-position ETA.
- Replaced the unsupported numeric "forecast confidence" claim with a transparent **forecast reliability** label based on the number of historical service samples.
- Forecast cards explicitly say `forecast wait`.
- Student dashboard labels the user's ETA as **Your current estimated wait**.
- Backend Python files pass `py_compile` validation.

The frontend dependencies are intentionally not bundled; run `npm install` in `frontend` on the Mac where the project is being used.
